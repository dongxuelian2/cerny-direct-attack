# Independently checked flag quotient and real-filtration pool exclusion

Python >=3.10; replay uses only the standard library. Historical baseline snapshots are opaque bound data. Geometry: b1_out_c4_third3
Scope: all native first-pair prefixes.
Every quotient conjugates the whole alphabet by one common state permutation.
No independent relabelling of letters and no depth12 safety premise is used.
The checker reconstructs each literal-row transport and every omitted child.
The 406-row pool uses twelve real-filtration growth domains and a 103-node finite cover.
Every stored word is checked directly; solver status is not proof.
Protected-state avoidability justifies strict span growth; no folded synchronization is claimed.
From _qa move aside exactly the following eighteen stored reports:
supplier_image_controls_audit_20261011.json
supplier_image_horizon_audit_20261011.json
supplier_products_audit_20261012.json
supplier_product_extensions_audit_20261012.json
supplier_triples_v2_audit_20261012.json
supplier_triples_v3_audit_20261012.json
obligatory_supplier_split_audit_20261012.json
obligatory_supplier_split_extended_audit_20261012.json
candidate967_common_literal_word_cuts_20261012.json
candidate967_real_filtration_audit_20261012.json
candidate967_growth_cover_tree_audit_20261012.json
candidate967_growth_cover_adversarial_audit_20261012.json
filtration_pool_exclusion_audit_20261012.json
b1_out_c4_third3_graph_quotient_scope.json
flag_stabilizer_quotient_audit_20261012.json
b1_out_c4_third3_graph_quotient_transport_audit.json
b1_out_c4_third3_graph_transport_protection_audit.json
b1_out_c4_third3_product_supplier_from0_v12_probe.json

Then run in order:
python -B audit_supplier_image_controls.py 
python -B audit_supplier_image_horizon.py 
python -B audit_supplier_products.py 
python -B audit_supplier_product_extensions.py 
python -B audit_supplier_triples_v2.py 
python -B audit_supplier_triples_v3.py 
python -B audit_obligatory_supplier_split_20261012.py 
python -B audit_obligatory_supplier_split_extended_20261012.py 
python -B build_candidate967_common_word_cuts_20261012.py 
python -B audit_candidate967_real_filtration_20261012.py 
python -B audit_candidate967_growth_cover_tree_20261012.py 
python -B audit_candidate967_growth_cover_adversarial_20261012.py 
python -B audit_filtration_pool_exclusion_20261012.py 
python -B compile_native_graph_quotient.py b1_out_c4_third3
python -B audit_flag_stabilizer_quotient_20261012.py 
python -B check_native_graph_quotient.py b1_out_c4_third3
python -B check_native_graph_protection.py b1_out_c4_third3
python -B probe_filtration_flags_range_v12.py b1_out_c4_third3 0

All eighteen reports must match their stored SHA256, including the complete flag tree.
The observed replay is on Windows; other platforms may need newline normalization.
Selected-prefix success is not a whole-geometry exclusion. Full success is a
conditional geometry certificate and still requires a separate adoption audit.
Neither mode establishes a new numerical extremum, alphabet separation or a
complete answer to Open Problem4. The accepted publication is unchanged.
