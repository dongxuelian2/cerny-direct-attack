# Complete conditional binary native-geometry certificate

Python >=3.10; standard library only. Geometry: b2_mixed_c4_third2
From _qa move aside the seven stored reports listed in REPORTS, then run:
python -B audit_binary_supplier_cover_20261012.py 
python -B audit_supplier_image_controls.py 
python -B audit_supplier_image_horizon.py 
python -B compile_native_graph_quotient.py b2_mixed_c4_third2
python -B check_native_graph_quotient.py b2_mixed_c4_third2
python -B check_native_graph_protection.py b2_mixed_c4_third2
python -B probe_binary_supplier_range_v1.py b2_mixed_c4_third2 0

The isolated replay regenerates all seven reports byte-identically.
Every transported first pair and every binary flag child is checked.
The supplier-coverage rule applies only to alphabets of at most two
literal letters. It does not exclude arbitrary finite alphabets.
Each literal pool and tree has an independent literal/rational checker.
The image-propagation rule and binary coverage rule have independently
replayed controls. No depth12 safety premise is used.
This excludes the stated geometry conditionally at (13,9,1),target12,
for binary automata only. It establishes no new F value or separation.
