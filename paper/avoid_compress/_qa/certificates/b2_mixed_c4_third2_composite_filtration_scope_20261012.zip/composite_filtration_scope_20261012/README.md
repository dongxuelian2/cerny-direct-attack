# Composite native-prefix scope audit

Python >=3.10, standard library. Run in this directory.
The two stored negative arrays cover exactly0..966 and967..1638.
Candidate967 in the first report is not counted as a negative.
This package checks assembly, all native prefix metadata and aggregate counts.
It is not a replay of the individual proof trees. Separate immutable packages
must replay both drivers and all independent literal/rational tree checks
before any authoritative exclusion. No F value or alphabet separation follows.
Move aside b2_mixed_c4_third2_composite_filtration_scope_audit_20261012.json and run:
python -B audit_composite_filtration_scope_20261012.py
The recreated report must have the stored SHA256.
