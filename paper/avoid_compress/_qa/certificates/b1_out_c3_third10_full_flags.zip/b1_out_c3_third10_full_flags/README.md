# Complete graph-first flag certificate for one native geometry

Python >=3.10; standard library only.
From _qa, move aside the four stored JSON reports named in REPORTS of
package_full_graph_quotient.py, then run in order:
python -B compile_graph_quotient_scope.py
python -B check_graph_quotient_scope.py
python -B check_graph_transport_protection.py
python -B probe_complete_graph_quotient.py

All four reports regenerate byte identically. The last command can take substantial time.
The scope is this enumerated native geometry at (13,9,1), target ac=12,
including every retained P1 graph and ordered initial pair. It uses the
existing literal/rational flag engine; a depth11 survivor aborts the exclusion.
The certificate supplies no new numerical F value or alphabet separation.
