# Complete native geometry with supplier-image pruning

Python >=3.10; standard library only.
Geometry: b2_mixed_c6_third11

From _qa move aside the six stored JSON reports listed in REPORTS of
package_full_supplier_image_quotient.py, then run in order:
python -B audit_supplier_image_controls.py 
python -B audit_supplier_image_horizon.py 
python -B compile_native_graph_quotient.py b2_mixed_c6_third11
python -B check_native_graph_quotient.py b2_mixed_c6_third11
python -B check_native_graph_protection.py b2_mixed_c6_third11
python -B probe_full_supplier_image_quotient.py b2_mixed_c6_third11

The recorded Windows replay regenerates all six reports byte-identically.
Other platforms may require newline normalization for byte comparison.
This is the complete native graph and ordered first-pair domain at
(13,9,1), target12. Every literal pool and flag branch has an independent
literal/rational checker. The additional rule proof is in
SUPPLIER_IMAGE_PROPAGATION.md; initial image depths and obligatory groups
come from the actual-image equality-flag induction. A depth11 survivor
aborts the exclusion. No safety at depth12 is used. This conditional
geometry certificate supplies no new numerical F value or separation.
