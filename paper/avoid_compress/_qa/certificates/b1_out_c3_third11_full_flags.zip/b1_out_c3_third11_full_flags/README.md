# Complete graph-first flag certificate for one native geometry

Python >=3.10; standard library only.
Geometry: b1_out_c3_third11

From _qa, move aside the four stored JSON reports named in REPORTS of
package_native_graph_quotient.py, then run in order:
python -B compile_native_graph_quotient.py b1_out_c3_third11
python -B check_native_graph_quotient.py b1_out_c3_third11
python -B check_native_graph_protection.py b1_out_c3_third11
python -B probe_native_graph_quotient.py b1_out_c3_third11

All four reports regenerate byte identically. The last command can take substantial time.
The scope is this enumerated native geometry at (13,9,1), target ac=12,
including every retained P1 graph and ordered initial pair. It uses the
existing literal/rational flag engine; a depth11 survivor aborts the exclusion.
The certificate supplies no new numerical F value or alphabet separation.
