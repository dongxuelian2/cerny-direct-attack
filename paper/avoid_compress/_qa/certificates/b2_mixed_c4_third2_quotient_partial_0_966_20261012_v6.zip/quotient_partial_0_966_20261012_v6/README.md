# Independently checked flag-stabilizer quotient

Python >=3.10; replay uses only the standard library. Historical baseline snapshots are opaque bound data. Geometry: b2_mixed_c4_third2
Scope: complete negative prefixes0..966, candidate967 not excluded.
Every quotient conjugates the whole alphabet by one common state permutation.
No independent relabelling of letters and no depth12 safety premise is used.
The checker reconstructs each literal-row transport and every omitted child.
From _qa move aside exactly the following thirteen stored reports:
supplier_image_controls_audit_20261011.json
supplier_image_horizon_audit_20261011.json
supplier_products_audit_20261012.json
supplier_product_extensions_audit_20261012.json
supplier_triples_v2_audit_20261012.json
supplier_triples_v3_audit_20261012.json
obligatory_supplier_split_audit_20261012.json
obligatory_supplier_split_extended_audit_20261012.json
b2_mixed_c4_third2_graph_quotient_scope.json
flag_stabilizer_quotient_audit_20261012.json
b2_mixed_c4_third2_graph_quotient_transport_audit.json
b2_mixed_c4_third2_graph_transport_protection_audit.json
b2_mixed_c4_third2_product_supplier_from0_v8_probe.json

Then run in order:
python -B audit_supplier_image_controls.py 
python -B audit_supplier_image_horizon.py 
python -B audit_supplier_products.py 
python -B audit_supplier_product_extensions.py 
python -B audit_supplier_triples_v2.py 
python -B audit_supplier_triples_v3.py 
python -B audit_obligatory_supplier_split_20261012.py 
python -B audit_obligatory_supplier_split_extended_20261012.py 
python -B compile_native_graph_quotient.py b2_mixed_c4_third2
python -B audit_flag_stabilizer_quotient_20261012.py 
python -B check_native_graph_quotient.py b2_mixed_c4_third2
python -B check_native_graph_protection.py b2_mixed_c4_third2
python -B probe_quotient_flags_range_v8.py b2_mixed_c4_third2 0

All thirteen reports must match their stored SHA256, including the complete flag tree.
The observed replay is on Windows; other platforms may need newline normalization.
Selected-prefix success is not a whole-geometry exclusion. Full success is a
conditional geometry certificate and still requires a separate adoption audit.
Neither mode establishes a new numerical extremum, alphabet separation or a
complete answer to Open Problem4. The accepted publication is unchanged.
