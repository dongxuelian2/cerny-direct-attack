"""Exhaustive small controls for a missing folded compressibility premise."""
from collections import deque,Counter
from hashlib import sha256
from itertools import product,combinations_with_replacement
import json
from pathlib import Path
HERE=Path(__file__).resolve().parent

def bfs(start,successors):
    distance={start:0};word={start:()};todo=deque([start])
    while todo:
        x=todo.popleft()
        for j,y in enumerate(successors(x)):
            if y not in distance:distance[y]=distance[x]+1;word[y]=word[x]+(j,);todo.append(y)
    return distance,word

def digest(p):return sha256(p.read_bytes()).hexdigest()

def main():
    dest=HERE/'fold_compressibility_audit_20261012.json';assert not dest.exists()
    counts=Counter();examples=[]
    for n in range(2,5):
        Q=(1<<n)-1;rows=list(product(range(n),repeat=n));images=[]
        for row in rows:images.append([sum(1<<q for q in {row[p] for p in range(n) if S>>p&1}) for S in range(1<<n)])
        for a,b in combinations_with_replacement(range(len(rows)),2):
            counts['binary_transition_pairs']+=1;letters=[rows[a],rows[b]];maps=[images[a],images[b]]
            if any(len(bfs(p,lambda q:[f[q] for f in letters])[0])!=n for p in range(n)):continue
            counts['strongly_connected_pairs']+=1
            full,words=bfs(Q,lambda S:[f[S] for f in maps]);sync=any(S.bit_count()==1 for S in full)
            subset_cache={}
            for alpha in range(n):
                avoiding=next((S for S in full if not(S>>alpha&1)),None)
                if avoiding is None:counts['unavoidable_protected_states']+=1;continue
                counts['avoidable_protected_states']+=1;z=words[avoiding];assert z
                f=list(range(n))
                for j in z:f=[letters[j][p] for p in f]
                assert alpha not in f
                orbit=[];q=alpha
                while q not in orbit:orbit.append(q);q=f[q]
                h=orbit.index(q);d=len(orbit)-h;assert h>=1 and d>=1
                p=alpha
                for _ in range(d):p=f[p]
                assert p!=alpha
                x,y=alpha,p
                for _ in range(h):x,y=f[x],f[y]
                assert x==y;counts['literal_merging_partner_checks']+=1
                for T in range(1,1<<n):
                    t=T.bit_count()
                    if t<2 or not(T>>alpha&1):continue
                    if T not in subset_cache:subset_cache[T]=bfs(T,lambda S:[f[S] for f in maps])
                    reached,labels=subset_cache[T]
                    bad=[distance for S,distance in reached.items() if S.bit_count()<t or not(S>>alpha&1)]
                    assert bad;ac=min(bad)
                    if ac<=n-t:counts['short_failure_outside_premise']+=1;continue
                    distances=[distance for S,distance in reached.items() if S.bit_count()<t]
                    assert distances,(n,letters,T,alpha,ac)
                    path=min((labels[S] for S in reached if S>>p&1),key=len)
                    assert len(path)<=n-t
                    U=T
                    for j in path:U=maps[j][U]
                    assert U.bit_count()==t and U>>alpha&1 and U>>p&1
                    for j in z*h:U=maps[j][U]
                    assert U.bit_count()<t
                    counts['applicable_subsets']+=1
                    if T not in full:counts['unreachable_subset_controls']+=1
                    if not sync:counts['nonsynchronizing_controls']+=1
                    if t<n:counts['proper_subset_controls']+=1
                    if not sync and len(examples)<4:examples.append(dict(n=n,rows=[list(f) for f in letters],T=T,alpha=alpha,ac=ac,compression=min(distances),avoiding_word=list(z)))
        print(json.dumps(dict(completed_n=n,counts=dict(counts))),flush=True)
    assert counts['binary_transition_pairs']==33284 and counts['applicable_subsets']>0 and counts['proper_subset_controls']>0
    out=dict(status='pass',maximum_n=4,counts=dict(counts),nonsynchronizing_controls=examples,
        no_geometry_exclusion=True,no_new_numerical_extremum=True,
        scope='Exhaustive small premise controls only; no complete finite extremal domain or folded synchronization/reachability conclusion.',
        source_sha256={n:digest(HERE/n) for n in [Path(__file__).name,'FOLD_COMPRESSIBILITY_PREMISE_20261012.md',
            'QUALIFIED_PROTECTED_FOLD.md','FOLD_AVOIDABILITY_FLAG.md','RANK_WORD_COMPRESSION_PRUNING_20261012.md']})
    dest.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)
if __name__=='__main__':main()
