"""Literal pool provenance for a saved quotient flag; no complete path exclusion."""
from hashlib import sha256
import json,mmap,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent/'investigation';sys.path.insert(0,str(ROOT))
from c1_word_staircase_letter_generator import pool
from check_c1_word_staircase import literal_pool
from check_b3_staircase import rat_rref
def digest(p):
    h=sha256()
    with p.open('rb') as f:
        while data:=f.read(8<<20):h.update(data)
    return h.hexdigest()
def candidate(p):
    with p.open('rb') as f:
        with mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ) as m:
            pos=m.rfind(b'"candidate":');assert pos>=0
            obj=json.loads(b'{'+m[pos:]);return obj['candidate'],obj
def read(p):return json.loads(p.read_text())
def main():
    scope=read(HERE/'b2_mixed_c4_third2_graph_quotient_scope.json');parent=read(HERE/'b2_mixed_c4_third2_inverse_probe.json')
    prefix=scope['prefixes'][967]
    old=next(z for z in parent['records'] if z['P1_mask']==prefix['P1_mask'] and z['reason']=='retained_overapproximation')
    args=dict(mandatory=parent['mandatory'],required_P3_edges=old['G'],fields=parent['fields'])
    view=dict(extra_pair=None,field_kernel_masks=old['field_kernel_masks']);basis=prefix['basis']
    B,C,D=map(set,[parent[k] for k in ('B','C','D')]);S,T=[{q for q in range(13) if m>>q&1} for m in basis]
    rows,G=pool(args,view,S,T,B,C,D);literal,H=literal_pool(args,view,basis,B,C,D);assert rows==literal and G==H
    inputs=[('b2_mixed_candidate967_literal_pool_20261012.json','b2_mixed_c4_third2_product_supplier_from0_v8_probe.json')]
    records=[];bindings={}
    for small,big in inputs:
        c=read(HERE/small)['candidate'];original,tail=candidate(HERE/big);assert c==original
        assert c['prefix']==967 and c['P1_mask']==prefix['P1_mask'] and c['initial_basis']==basis and len(c['basis'])==12
        positions=c['original_letter_indices'];assert positions==sorted(set(positions))
        assert c['rows']==[list(literal[i][0]) for i in positions] and c['supplier_flags']==[literal[i][1] for i in positions]
        assert len(rat_rref(c['basis']))==12 and all(m.bit_count()==9 and m&8 for m in c['basis'])
        expected=[[j for j,i in enumerate(positions) if literal[i][1]>>k&1] for k in range(4)]
        for i in range(1,11):
            source={q for q in range(13) if c['basis'][i]>>q&1};target={q for q in range(13) if c['basis'][i+1]>>q&1}
            expected.append([j for j,row in enumerate(c['rows']) if {row[q] for q in source}==target])
        assert c['required_groups']==expected and all(expected)
        for base,key,tag in [(HERE,'source_sha256',''),(ROOT,'root_source_sha256','root:')]:
            for n,h in tail.get(key,{}).items():assert digest(base/n)==h,n;bindings[tag+n]=h
        bindings[small]=digest(HERE/small);bindings[big]=digest(HERE/big)
        records.append(dict(saved_pool=small,origin=big,rows=len(c['rows']),required_groups=len(expected),rank=12))
    roots=['c1_word_staircase_letter_generator.py','check_c1_word_staircase.py','check_b3_staircase.py']
    out=dict(status='pass',prefix=967,literal_original_pool=len(literal),records=records,
             independently_rebuilt_literal_pool=True,conditional_word_product_premises_verified=True,
             complete_original_flag_path_replay=False,no_geometry_exclusion=True,no_new_numerical_extremum=True,
             source_sha256={Path(__file__).name:digest(Path(__file__)),**{n:h for n,h in bindings.items() if not n.startswith('root:')}},
             root_source_sha256={**{n:digest(ROOT/n) for n in roots},**{n[5:]:h for n,h in bindings.items() if n.startswith('root:')}})
    p=HERE/'b2_candidate967_saved_origin_audit_20261012.json';assert not p.exists()
    p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k not in ('source_sha256','root_source_sha256')}),flush=True)
if __name__=='__main__':main()
