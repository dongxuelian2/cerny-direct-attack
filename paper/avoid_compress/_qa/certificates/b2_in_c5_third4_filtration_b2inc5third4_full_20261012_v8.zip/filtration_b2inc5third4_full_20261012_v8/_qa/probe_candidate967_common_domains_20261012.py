"""Weaker common ten-domain search with necessary SC and full-set avoidance."""
from collections import deque
from hashlib import sha256
import json,time
from pathlib import Path
import z3
HERE=Path(__file__).resolve().parent
def digest(p):return sha256(p.read_bytes()).hexdigest()
def main():
    dest=HERE/'candidate967_common_domains_synthesis_20261012.json';assert not dest.exists()
    pool='b2_mixed_candidate967_literal_pool_20261012.json';data=json.loads((HERE/pool).read_text())['candidate']
    rows=data['rows'];N=len(rows);S=data['basis'][0];Q=8191;cache={}
    def image(i,T):
        key=(i,T)
        if key not in cache:cache[key]=sum(1<<q for q in {rows[i][p] for p in range(13) if T>>p&1})
        return cache[key]
    def bfs(start,selected,state=False):
        words={start:()};todo=deque([start])
        while todo:
            T=todo.popleft()
            for i in selected:
                U=rows[i][T] if state else image(i,T)
                if U not in words:words[U]=words[T]+(i,);todo.append(U)
        return words
    def bad_word(selected,start,horizon,rank=False):
        words={start:()};todo=deque([start])
        while todo:
            T=todo.popleft();w=words[T]
            if len(w)==horizon:continue
            for i in selected:
                U=image(i,T)
                if (U.bit_count()<=9 if rank else U.bit_count()<9 or not(U&8)):return list(w+(i,))
                if U not in words:words[U]=w+(i,);todo.append(U)
        return None
    choose=[z3.Bool('e'+str(i)) for i in range(N)];solver=z3.Solver()
    required=data['required_groups'][:10]
    for R in required:solver.add(z3.Or([choose[i] for i in R]))
    seed_file='candidate967_augmented_literal_word_cuts_20261012.json';seed=json.loads((HERE/seed_file).read_text());assert seed['status']=='pass'
    for c in seed['clauses']:solver.add(z3.Or([z3.Not(choose[i]) for i in set(c['word'])]))
    learned=[];actual=None;iterations=0;start=time.monotonic();deadline=start+60;last='not_started'
    while time.monotonic()<deadline:
        solver.set(timeout=max(1,int((deadline-time.monotonic())*1000)));status=solver.check();last=str(status)
        if status!=z3.sat:break
        selected=[i for i in range(N) if z3.is_true(solver.model().eval(choose[i],model_completion=True))];iterations+=1
        word=bad_word(selected,Q,6,True);kind='short_rank_word'
        if word is None:word=bad_word(selected,S,11);kind='unsafe_word'
        if word is not None:
            solver.add(z3.Or([z3.Not(choose[i]) for i in set(word)]));learned.append(dict(kind=kind,word=word));continue
        closed=None
        for p in range(13):
            C=set(bfs(p,selected,True))
            if len(C)<13:closed=C;break
        if closed is not None:
            escape=[i for i,row in enumerate(rows) if any(row[p] not in closed for p in closed)]
            solver.add(z3.Or([choose[i] for i in escape]));learned.append(dict(kind='SC_escape',closed_states=sorted(closed),domain=escape));continue
        full=bfs(Q,selected);avoiding=[T for T in full if not(T&8)]
        if not avoiding:
            closure=set(full);escape=[i for i in range(N) if any(image(i,T) not in closure for T in closure)]
            solver.add(z3.Or([choose[i] for i in escape]));learned.append(dict(kind='avoidance_escape',closed_images=sorted(closure),domain=escape));continue
        local=bfs(S,selected);attain=min((w for T,w in local.items() if T.bit_count()<9 or not(T&8)),key=len)
        assert len(attain)==12
        resets=[w for T,w in full.items() if T.bit_count()==1]
        actual=dict(selected_indices=selected,rows=[rows[i] for i in selected],S=S,A=8,value=12,
            avoiding_word=list(full[min(avoiding,key=lambda T:len(full[T]))]),attaining_word=list(attain),
            strongly_connected=True,synchronizing=bool(resets),reachable_image=S in full,
            reset_word=list(min(resets,key=len)) if resets else None,reaching_word=list(full[S]) if S in full else None,
            word_indices='saved-pool indices',independent_original_requirements_audit_pending=True)
        last='relaxed_literal_model_pending_independent_audit';break
    out=dict(status='time_budget_exhausted_without_witness' if last=='sat' and actual is None else last,
        last_solver_status=last,parameter=[13,9,1],prefix=967,required_groups=required,
        initial_compulsory_groups=10,seed_conflicts=len(seed['clauses']),iterations=iterations,learned=learned,actual=actual,
        elapsed_seconds=time.monotonic()-start,complete_geometry_exclusion=False,no_authoritative_exclusion=True,
        no_new_numerical_extremum=True,
        scope='Weaker common-domain synthesis only. SC and protected-state avoidability are necessary; folded synchronization and image reachability are not inferred. UNSAT requires an independent finite cover proof.',
        source_sha256={n:digest(HERE/n) for n in [Path(__file__).name,pool,seed_file,'FOLD_COMPRESSIBILITY_PREMISE_20261012.md',
            'FOLD_AVOIDABILITY_FLAG.md','RANK_WORD_COMPRESSION_PRUNING_20261012.md']})
    dest.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k not in ('source_sha256','learned','actual','required_groups')}),flush=True)
if __name__=='__main__':main()
