"""Ordinary-set audit of all saved selector cuts; not a negative certificate."""
from hashlib import sha256
import json
from pathlib import Path
HERE=Path(__file__).resolve().parent
def main():
    pool='b2_mixed_candidate967_literal_pool_20261012.json';report='candidate967_alphabet_synthesis_20261012.json'
    rows=json.loads((HERE/pool).read_text())['candidate']['rows'];d=json.loads((HERE/report).read_text())
    assert d['actual'] is None and d['iterations']==len(d['cuts']) and d['complete_geometry_exclusion'] is False
    S={q for q in range(13) if json.loads((HERE/pool).read_text())['candidate']['basis'][0]>>q&1}
    for c in d['cuts']:
        assert c['kind']=='unsafe_word' and 1<=len(c['word'])<=11
        T=set(S)
        for i in c['word']:
            assert 0<=i<len(rows);T={rows[i][q] for q in T}
        assert len(T)<9 or 3 not in T
    out=dict(status='pass',cuts=len(d['cuts']),original_last_solver_status=d['status'],
        search_interpretation='The wall-time budget expired after learned unsafe-word cuts. SAT was only the last selector check; no safe literal automaton was found.',
        actual_witness_found=False,conditional_UNSAT_established=False,no_geometry_exclusion=True,no_new_numerical_extremum=True,
        source_sha256={n:sha256((HERE/n).read_bytes()).hexdigest() for n in [Path(__file__).name,pool,report]})
    p=HERE/'candidate967_selector_words_audit_20261012.json';assert not p.exists();p.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out),flush=True)
if __name__=='__main__':main()
