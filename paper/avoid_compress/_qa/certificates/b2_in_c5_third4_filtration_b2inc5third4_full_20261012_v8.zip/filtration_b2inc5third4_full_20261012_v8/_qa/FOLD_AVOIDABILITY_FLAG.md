# Avoidability and an odd-cardinality flag in the folded model

Auxiliary necessary-model proof; no new F value or alphabet separation.
It supplements QUALIFIED_PROTECTED_FOLD.md without asserting folded
synchronization or actual reachability of S'.

## Avoidability survives the active-port fold

Use the entrance normal form with one active protected port and common B.
For every T containing A, the folded one-step identities are valid even
when T has already compressed: their proof requires inclusion of A, not
the original cardinality of T. Until A first disappears from an image
Qw, these identities inductively identify its outside part with the
outside part of Q'w and retain alpha exactly when all of A is retained.

Original synchronization and strong connectivity give a word z taking
the full Q to a singleton outside A. At the first prefix of z whose
original full-set image fails to contain A, the folded full-set image
fails to contain alpha. Thus alpha is avoidable in the folded model.
This proof stops at the first loss; it does not project arbitrary images
after that loss. No assertion that the same full word resets the fold is
made. The normal-form boundary in FOLD_SYNCHRONIZATION_BOUNDARY.md is
indeed nonsynchronizing after folding but has an avoidable alpha.

## Equality flags without folded synchronization

Let a complete N-state automaton have a proper subset T of size t>=2,
a protected alpha in T, and ac(T,{alpha})=N-1. Suppose alpha is avoidable
from the full state set. Let V_i be the span of trajectory rows
chi_T D_w for |w|<=i, using counting trajectories after collisions.

Over R, every row through depth N-2 is characteristic, has total t,
and has alpha-coordinate one. Hence V_(N-2) is contained in the
(N-1)-dimensional homogeneous hyperplane

    H={x: t x_alpha=sum x}.

A word avoiding alpha from the full set gives a trajectory row with
alpha-coordinate zero and total t, so V_infinity is not contained in H.
Consequently V_i cannot plateau for i<=N-2: a plateau stabilizes under
all letters forever. Starting from dimension one, the N-2 strict
inclusions before V_(N-2) exhaust its dimension budget N-1. Therefore
dim V_i=i+1 for 0<=i<=N-2. This is the same proof mechanism as the known
avoid-or-compress lemma, with avoidability replacing a folded reset.

If t is ODD, the identical argument works over F2. Safe rows have total
one and alpha-coordinate one, so H={x:x_alpha=sum x} has dimension N-1.
An avoiding trajectory still has total one after collisions because
every right-action transformation matrix has row sums one. It lies
outside H. Thus the F2 prefix ranks are also i+1 through N-2.
No odd-cardinality conclusion is asserted when t is even.

Apply this to the qualified fold. N=q+1 and t=|S'|=g+1. Its real flag
was already inherited; its F2 flag is now justified whenever g is even,
REGARDLESS of the parity of the original |S|=r+g. In particular at
n=r+12, |S|=n-4, every r>=1 gives a necessary thirteen-state nine-set
model with both real and F2 flags through depth eleven. This permits
the existing odd-set flag encoding in a future relaxed folded search;
positives still require all original manuscript checks before becoming
extremal witnesses. No failed solver run gives a negative certificate.

## Boundary of the avoidability hypothesis

The five-state model

    a=[3,0,0,4,2], b=[3,0,0,4,1]

is strongly connected and singular, but state 0 is unavoidable from Q.
Both letters cyclically permute the four color blocks
{1,2}, {0}, {3}, {4}. Every word image of Q therefore meets all four
blocks, including the singleton {0}. SC and singularity alone
do not supply the avoiding word used above. This is not a qualified
equality witness.
