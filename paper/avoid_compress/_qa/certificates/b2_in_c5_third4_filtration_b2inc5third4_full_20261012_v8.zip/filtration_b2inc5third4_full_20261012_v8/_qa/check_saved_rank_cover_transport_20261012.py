"""Independent ordinary-set transport and finite cover replay."""
from functools import lru_cache
from hashlib import sha256
import json
from pathlib import Path
from check_candidate967_cover_tree_20261012_v2 import check as check_cover
HERE=Path(__file__).resolve().parent

@lru_cache(maxsize=1)
def verified_saved():
    pool_name='b2_mixed_candidate967_literal_pool_20261012.json';cover_name='candidate967_cover_tree_audit_20261012.json'
    pool=json.loads((HERE/pool_name).read_text())['candidate'];proof=json.loads((HERE/cover_name).read_text())
    assert proof['status']=='pass' and proof['prefix']==967 and proof['complete_saved_pool_cover_exclusion']
    S={q for q in range(13) if pool['basis'][0]&(1<<q)}
    counts=check_cover(pool['rows'],S,pool['required_groups'],proof['clauses'],proof['tree'])
    assert counts==proof['counts']
    return pool,counts,pool_name,cover_name,sha256((HERE/pool_name).read_bytes()).hexdigest(),sha256((HERE/cover_name).read_bytes()).hexdigest()

def check_certificate(rows,active,required,S,record):
    pool,counts,pn,cn,hp,hc=verified_saved()
    assert record['kind']=='saved_literal_rank_cover' and record['initial_image']==S==pool['basis'][0]
    assert record['saved_pool']==pn and record['saved_cover']==cn
    assert record['saved_pool_sha256']==hp and record['saved_cover_sha256']==hc
    assert 0<active and active.bit_length()<=len(rows) and all(R>=0 for R in required)
    ids=[i for i in range(len(rows)) if active&(1<<i)]
    transport=record['transport'];assert [i for i,j in transport]==ids
    assert len({j for i,j in transport})==len(transport)
    correspondence={}
    for i,j in transport:
        assert 0<=j<len(pool['rows']) and list(rows[i])==pool['rows'][j]
        correspondence[i]=j
    domains=[{correspondence[i] for i in ids if R&(1<<i)} for R in required]
    assert domains and all(domains)
    implications=record['compulsory_group_implications']
    assert [k for k,j in implications]==list(range(len(pool['required_groups'])))
    for k,j in implications:
        assert 0<=j<len(domains) and domains[j]<=set(pool['required_groups'][k])
    return dict(active_letters=len(ids),saved_compulsory_groups=len(implications),cover_nodes=counts['nodes'])
