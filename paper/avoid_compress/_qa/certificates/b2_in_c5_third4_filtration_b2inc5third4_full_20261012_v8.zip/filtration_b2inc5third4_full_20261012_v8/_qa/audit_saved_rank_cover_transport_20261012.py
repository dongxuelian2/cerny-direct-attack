"""Primitive row/group transports and invalid-premise controls."""
from copy import deepcopy
from hashlib import sha256
import json
from pathlib import Path
from saved_rank_cover_transport_20261012 import certificate
from check_saved_rank_cover_transport_20261012 import check_certificate
HERE=Path(__file__).resolve().parent
def digest(p):return sha256(p.read_bytes()).hexdigest()
def main():
    dest=HERE/'saved_rank_cover_transport_audit_20261012.json';assert not dest.exists()
    source='b2_mixed_candidate967_literal_pool_20261012.json';pool=json.loads((HERE/source).read_text())['candidate']
    rows=pool['rows'];N=len(rows);active=(1<<N)-1;S=pool['basis'][0]
    R=[sum(1<<i for i in g) for g in pool['required_groups']]
    base=certificate(rows,active,R,S);assert base
    result=check_certificate(rows,active,R,S,base);assert result==dict(active_letters=406,saved_compulsory_groups=14,cover_nodes=104)
    positives=[result]
    permuted=[rows[i] for i in range(N-1,-1,-1)]
    changed_R=[sum(1<<(N-1-i) for i in g) for g in pool['required_groups']]
    for rs,a,groups in [(permuted,active,changed_R),(rows,active&~(1<<(N-1)),R),(rows,active,R+[1])]:
        proof=certificate(rs,a,groups,S);assert proof
        positives.append(check_certificate(rs,a,groups,S,proof))
    rejected=[]
    def test(label,change):
        p=deepcopy(base);other=dict(rows=deepcopy(rows),active=active,required=list(R),S=S);change(p,other)
        try:check_certificate(other['rows'],other['active'],other['required'],other['S'],p)
        except (AssertionError,KeyError):rejected.append(label)
        else:raise AssertionError('Accepted invalid rank-cover transport: '+label)
    test('missing active literal row',lambda p,o:p['transport'].pop())
    test('duplicate saved literal image',lambda p,o:p['transport'][1].__setitem__(1,p['transport'][0][1]))
    test('invalid saved row index',lambda p,o:p['transport'][0].__setitem__(1,N))
    test('missing compulsory-group implication',lambda p,o:p['compulsory_group_implications'].pop())
    test('invented compulsory source domain',lambda p,o:p['compulsory_group_implications'][0].__setitem__(1,len(R)))
    test('empty native compulsory domain',lambda p,o:o['required'].__setitem__(0,0))
    test('wrong saved pool digest',lambda p,o:p.update(saved_pool_sha256='0'*64))
    test('wrong saved proof digest',lambda p,o:p.update(saved_cover_sha256='0'*64))
    test('wrong initial image',lambda p,o:o.update(S=S^1))
    test('changed literal transformation',lambda p,o:o['rows'][0].__setitem__(0,(o['rows'][0][0]+1)%13))
    extended=rows+[[0]*13]
    assert certificate(extended,active|(1<<N),R,S) is None
    assert certificate(rows,active,[0,*R[1:]],S) is None
    assert certificate(rows,active,R,S^1) is None
    out=dict(status='pass',positive_transports=positives,corruptions_rejected=rejected,
        inapplicable_domain_controls=3,saved_cover_nodes=104,no_geometry_exclusion=True,no_new_numerical_extremum=True,
        complete_original_flag_path_replay=False,
        source_sha256={n:digest(HERE/n) for n in [Path(__file__).name,'saved_rank_cover_transport_20261012.py',
            'check_saved_rank_cover_transport_20261012.py','SAVED_RANK_COVER_TRANSPORT_20261012.md',source,
            'candidate967_cover_tree_audit_20261012.json','check_candidate967_cover_tree_20261012_v2.py',
            'RANK_WORD_COMPRESSION_PRUNING_20261012.md','FOLD_COMPRESSIBILITY_PREMISE_20261012.md',
            'fold_compressibility_audit_20261012.json','saved_rank_cover_transport_20261012.py']})
    dest.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='source_sha256'}),flush=True)
if __name__=='__main__':main()
