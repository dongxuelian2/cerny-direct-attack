"""Produce a complete finite cover tree from literal word cuts, without SMT."""
from hashlib import sha256
import json,time
from pathlib import Path
from check_candidate967_cover_tree_20261012 import check
HERE=Path(__file__).resolve().parent

def digest(p):return sha256(p.read_bytes()).hexdigest()

def main():
    dest=HERE/'candidate967_cover_tree_audit_20261012.json';assert not dest.exists()
    pool='b2_mixed_candidate967_literal_pool_20261012.json';c=json.loads((HERE/pool).read_text())['candidate']
    rows=c['rows'];groups=c['required_groups'];N=len(rows);assert N==406 and len(groups)==14
    sources=['candidate967_alphabet_synthesis_20261012.json','candidate967_alphabet_rank_synthesis_20261012.json']
    unique={}
    for name in sources:
        d=json.loads((HERE/name).read_text());assert d['actual'] is None
        for cut in d['cuts']:
            key=tuple(sorted(set(cut['word'])));unique.setdefault(key,cut)
    keys=sorted(unique,key=lambda k:(len(k),k));clauses=[unique[k] for k in keys]
    negative=[sum(1<<i for i in k) for k in keys];positive=[sum(1<<i for i in g) for g in groups]
    nodes=0;deadline=time.monotonic()+60
    def visit(F,D):
        nonlocal nodes
        nodes+=1
        if time.monotonic()>deadline:raise TimeoutError('Complete finite cover proof not obtained within budget')
        assert not F&D;units=[]
        while True:
            changed=False
            for j,R in enumerate(positive):
                if R&F:continue
                rest=R&~D
                if not rest:return dict(units=units,reason='missing_group',group=j)
                if rest.bit_count()==1:
                    F|=rest;units.append(dict(kind='force',group=j,letter=rest.bit_length()-1));changed=True
            for j,R in enumerate(negative):
                if R&D:continue
                rest=R&~F
                if not rest:return dict(units=units,reason='forbidden_alphabet',clause=j)
                if rest.bit_count()==1:
                    D|=rest;units.append(dict(kind='delete',clause=j,letter=rest.bit_length()-1));changed=True
            if not changed:break
        choices=[((R&~D).bit_count(),j,R&~D) for j,R in enumerate(positive) if not R&F]
        assert choices,'Found a satisfying cover contrary to the independent finite contradiction request'
        _,j,R=min(choices);children=[];prior=0
        for i in range(N):
            if R>>i&1:
                children.append(dict(letter=i,node=visit(F|(1<<i),D|prior)));prior|=1<<i
        return dict(units=units,reason='all_first_suppliers_rejected',group=j,children=children)
    tree=visit(0,0);S={q for q in range(13) if c['basis'][0]>>q&1};counts=check(rows,S,groups,clauses,tree)
    assert counts['nodes']==nodes
    out=dict(status='pass',prefix=967,conditional_pool=N,required_groups=14,distinct_forbidden_alphabets=len(clauses),
        counts=counts,tree=tree,clauses=clauses,complete_saved_pool_cover_exclusion=True,
        complete_original_flag_path_replay=False,complete_geometry_exclusion=False,no_authoritative_exclusion=True,no_new_numerical_extremum=True,
        scope='Finite independently checked cover contradiction for one conditional saved flag. Rank clauses use the existing compressible-subset rank-word bound. No original flag-path replay or whole geometry exclusion.',
        source_sha256={n:digest(HERE/n) for n in [Path(__file__).name,'check_candidate967_cover_tree_20261012.py',pool,*sources,
            'b2_candidate967_saved_origin_audit_20261012.json','RANK_WORD_COMPRESSION_PRUNING_20261012.md',
            'rank_word_compression_audit_20261012.json','FOLD_COMPRESSIBILITY_PREMISE_20261012.md','fold_compressibility_audit_20261012.json']})
    dest.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k not in ('tree','clauses','source_sha256')}),flush=True)
if __name__=='__main__':main()
