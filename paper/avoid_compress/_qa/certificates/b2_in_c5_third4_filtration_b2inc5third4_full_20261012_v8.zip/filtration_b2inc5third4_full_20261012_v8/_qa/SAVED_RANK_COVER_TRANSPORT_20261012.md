# Conditional literal-pool cover transport

This is an auxiliary rejection rule at (N,t,alpha)=(13,9,3), under the
premise ac(T,{alpha})>=12 and eventual compressibility of T. It supplies
no numerical extremum on its own and assumes no safety at depth twelve.

The independently checked saved cover proof concerns a literal pool L*,
a specific initial nine-set T, and fourteen obligatory subsets R*_k.
Every alphabet E* contained in L* meeting all fourteen subsets contains
one of its forbidden letter sets. Each forbidden set has an explicit
word either unsafe from T in at most eleven letters, or of rank at most
nine in at most six letters. The latter contradicts compression length
at least twelve by the existing rank-word bound: for rank nine the bound
is 13-9+6+1=11, and smaller rank compresses T directly. This is a reuse of
the known transversal method, not a novelty claim.

At a native flag node, let L be its active literal pool and R_j its
compulsory subsets. Require an injective map L -> L* that preserves every
entire state transformation literally; this map only reindexes letters.
For every saved R*_k require some nonempty native R_j whose complete
active image lies in R*_k. Then any actual E contained in L meeting every
native R_j maps to an E* meeting all saved R*_k. The same word uses the
same transformations, with the same length, state image and rank. The
saved contradiction therefore excludes E. No unrelated letters may be
introduced, and merely matching supplier counts is insufficient.

All active rows, not just representatives, are checked. Every saved
compulsory group needs its own explicit implication. The independent
checker reconstructs these inclusions with ordinary sets and replays
the saved finite cover tree and every literal word. The generator uses
bit masks to find the inclusions. The primitive controls include row
reindexing, restriction of the active domain, a stronger compulsory
condition and deliberately invalid transports.

Native flag trees provide the compulsory domains along the actual
prefix-image induction. A full selected-prefix replay must independently
check that path before this primitive becomes a prefix exclusion. Its
control on a previously saved flag alone does not constitute that replay.

In the manuscript domain synchronization supplies compressibility. For
the necessary qualified fold, strong connectivity, avoidability of alpha
and ac>=12>13-9 supply it by FOLD_COMPRESSIBILITY_PREMISE_20261012.md.
This does not imply folded synchronization or reachable-image status.
