"""Exhaustive ordinary subset-graph controls for the existing transversal method."""
from collections import deque,Counter
from hashlib import sha256
from itertools import product,combinations_with_replacement
import json
from pathlib import Path
HERE=Path(__file__).resolve().parent
def digest(p):return sha256(p.read_bytes()).hexdigest()
def main():
    counts=Counter();examples=[]
    for n in range(2,5):
        Q=(1<<n)-1;rows=list(product(range(n),repeat=n));images=[]
        for row in rows:
            images.append([sum(1<<t for t in {row[q] for q in range(n) if S>>q&1}) for S in range(1<<n)])
        for a,b in combinations_with_replacement(range(len(rows)),2):
            maps=[images[a],images[b]];counts['automata']+=1
            rev=[set() for _ in range(1<<n)]
            for S in range(1<<n):
                for f in maps:rev[f[S]].add(S)
            reached={Q:0};todo=deque([Q])
            while todo:
                S=todo.popleft()
                for f in maps:
                    T=f[S]
                    if T not in reached:reached[T]=reached[S]+1;todo.append(T)
            for s in range(2,n+1):
                ranks=[h for T,h in reached.items() if T.bit_count()==s]
                if not ranks:continue
                h=min(ranks);counts['rank_word_controls']+=1
                d={S:0 for S in range(1<<n) if S.bit_count()<s};todo=deque(d)
                while todo:
                    T=todo.popleft()
                    for S in rev[T]:
                        if S not in d:d[S]=d[T]+1;todo.append(S)
                for S in range(1<<n):
                    if S.bit_count()!=s:continue
                    if S not in d:counts['uncompressible_premises_skipped']+=1;continue
                    assert d[S]<=n-s+h+1,(n,rows[a],rows[b],S,h,d[S])
                    counts['compression_inequalities']+=1
                    if S not in reached:counts['unreachable_S_controls']+=1
                    if not any(T.bit_count()==1 for T in reached):counts['nonsynchronizing_controls']+=1
                    if d[S]==n-s+h+1 and len(examples)<6:
                        examples.append(dict(n=n,s=s,rows=[list(rows[a]),list(rows[b])],S=S,rank_word_length=h,compression=d[S]))
        print(json.dumps(dict(completed_n=n,counts=dict(counts))),flush=True)
    assert counts['unreachable_S_controls'] and counts['nonsynchronizing_controls'] and counts['uncompressible_premises_skipped']
    out=dict(status='pass',maximum_n=4,alphabet_scope='Every unordered binary transition pair, including repeated letters and all s-subsets.',
             counts=dict(counts),equality_controls=examples,known_theory_only=True,
             no_geometry_exclusion=True,no_new_numerical_extremum=True,
             source_sha256={n:digest(HERE/n) for n in [Path(__file__).name,'RANK_WORD_COMPRESSION_PRUNING_20261012.md']})
    p=HERE/'rank_word_compression_audit_20261012.json';assert not p.exists()
    p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)
if __name__=='__main__':main()
