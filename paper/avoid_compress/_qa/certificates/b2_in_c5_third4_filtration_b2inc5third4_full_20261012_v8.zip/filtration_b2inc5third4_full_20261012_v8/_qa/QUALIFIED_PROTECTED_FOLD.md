# A qualified active-port fold

This is an auxiliary necessary-model reduction, not an exact formula for F.
It uses the already proved entrance-fiber and equality-flag lemmas; no
novelty or priority claim is made.

Let a strongly connected synchronizing automaton satisfy ac(S,A)=q=n-r,
where r=|A| and g=|S|-r>=3. Put O=Q minus A and m=n-|S|. The entrance-fiber
lemma gives one nonempty B subset O. Every letter is of exactly one form:

* It permutes A and has no outside predecessor of a protected output.
* It sends one protected input p to an outside output j, inserts all of B
  at one protected output a, and maps the other r-1 protected inputs
  bijectively to A minus {a}. All other outside inputs go outside A.

Replace A by one new state alpha, keeping O. An inactive letter fixes alpha;
an active letter sends alpha to j, the output of its unique active port p.
Every outside input keeps its outside output or goes to alpha if its
original output was protected. Set S'= {alpha} union (S minus A).
This need not be a transformation quotient: an inactive protected input of
an active letter is not represented by the chosen active port.

The folded model has n'=q+1, s'=g+1, m'=m and the same labelled alphabet.
The following properties hold.

1. It is strongly connected. In any original graph path, replace each
   maximal segment inside A by a visit to alpha. Its entry edge is retained.
   For its exit use the letter of the original exit edge: that edge comes
   from the unique active port, so alpha has exactly the required exit.
   Omit the internal protected steps. The same argument covers paths
   starting or ending in A. Original strong connectivity gives every
   required folded path.

2. ac(S',{alpha})=q. For any T containing A, put U={alpha} union (T minus A).
   Under an inactive letter, both images retain their full protected sets
   and have identical outside parts. Under an active letter the original
   image has r-1 protected outputs unconditionally; its remaining protected
   output occurs exactly when T meets B. The folded image contains alpha
   under exactly the same condition. Their outside parts are identical.
   Therefore |T ell|=(r-1)+|U ell'|, and A is contained in T ell exactly
   when alpha is in U ell'. Avoidance means losing at least one protected
   state. Induction through safe prefixes, including their first failing
   extension, proves equality of the two minimum lengths. Projection of
   arbitrary images after that failure is not asserted.

3. Every letter has the same corank in the two models. Apply the preceding
   one-step cardinality identity with T=Q. In particular a singular letter
   remains singular.

4. For every i<q the real row spans of the safe characteristic images
   through length i have equal rank i+1. All original protected columns
   equal one on these rows. Deleting r-1 duplicate protected columns gives
   the folded rows, and duplicating the remaining protected column
   recovers the original rows. Both maps are linear on these spans.
   The original ranks are those of LOCAL_EQUALITY_FLAG.md.

5. The pair graphs through depth g-1 agree on O; all protected endpoints
   are isolated in both models through that depth. Original isolation
   follows from ac<=m+d_A. For a folded pair {alpha,x} merging in d<g
   steps, strong connectivity supplies a path of length at most m from
   S' to x. It is safe, since m<q; hence it also contains alpha. Appending
   the merging word contradicts folded ac=q. Thus folded isolation holds
   without assuming folded synchronization. A merging word of length
   at most g-1 cannot pass through a non-diagonal pair touching a protected
   state: its remaining suffix would violate isolation. Until merging,
   its pair stays outside. Those transitions agree in the two models.
   If two outside points enter A under one letter, both belong to B and
   have the same protected output, so they merge in both models.

The conclusions do not supply folded synchronization or actual reachability
of S'. A singleton proof may be reused only after auditing each of its
hypotheses against these conclusions. In particular, no comparison with
the manuscript's F or F_bin follows automatically.

At m=4,q=12 this produces a 13-state, nine-set necessary model for every r,
not just r=1. Whether every existing structural exclusion transports to
this model still requires a separate premise audit.

The restriction g>=3 is essential to this construction. A binary boundary
control has Q={0,...,4}, A={0,1}, S={0,1,2,3}, and rows

    a=[2,3,0,1,1], b=[1,4,0,2,3].

Here Q a=S, b is a full cycle, the automaton synchronizes and ac=3=n-r.
Letter a has TWO active protected ports. Choosing either one as the single
folded port makes the first a compress S', giving folded ac=1. It is a
gap-two control, not a counterexample to the stated gap-three-or-larger
lemma. Its extremal value was already covered by the manuscript.
