"""Bounded exact-selector synthesis inside a saved necessary flag only.

Ordinary subset witnesses justify every learned clause. UNSAT is a
conditional solver result, not a new bound or a complete geometry proof.
"""
from collections import deque
from hashlib import sha256
import json,time
from pathlib import Path
import z3
HERE=Path(__file__).resolve().parent

def graph(start,actions):
    words={start:()};todo=deque([start])
    while todo:
        x=todo.popleft()
        for i,action in actions:
            y=action(x)
            if y not in words:words[y]=words[x]+(i,);todo.append(y)
    return words

def main():
    dest=HERE/'candidate967_alphabet_rank_synthesis_20261012.json';assert not dest.exists()
    source='b2_mixed_candidate967_literal_pool_20261012.json';data=json.loads((HERE/source).read_text());c=data['candidate']
    assert c['prefix']==967 and len(c['basis'])==12
    rows=c['rows'];N=len(rows);S=c['basis'][0];Q=(1<<13)-1;A=8
    cache={}
    def image(i,T):
        key=(i,T)
        if key not in cache:cache[key]=sum(1<<p for p in {rows[i][q] for q in range(13) if T>>q&1})
        return cache[key]
    choose=[z3.Bool('e'+str(i)) for i in range(N)];solver=z3.Solver()
    for R in c['required_groups']:assert R;solver.add(z3.Or([choose[i] for i in R]))
    seedfile='candidate967_alphabet_synthesis_20261012.json';auditfile='candidate967_selector_words_audit_20261012.json'
    audit=json.loads((HERE/auditfile).read_text());assert audit['status']=='pass'
    assert sha256((HERE/seedfile).read_bytes()).hexdigest()==audit['source_sha256'][seedfile]
    seed=json.loads((HERE/seedfile).read_text());assert seed['actual'] is None
    for cut in seed['cuts']:
        assert cut['kind']=='unsafe_word'
        solver.add(z3.Or([z3.Not(choose[i]) for i in set(cut['word'])]))
    cuts=[];actual=None;iterations=0;deadline=time.monotonic()+60;last='not_started'
    while time.monotonic()<deadline:
        solver.set(timeout=max(1,int((deadline-time.monotonic())*1000)))
        status=solver.check();last=str(status)
        if status!=z3.sat:break
        selected=[i for i in range(N) if z3.is_true(solver.model().eval(choose[i],model_completion=True))];iterations+=1
        # Existing rank-word lemma: an eventual compressible 9-set
        # with compression >=12 forbids rank<=9 words of length<=6.
        rank_words={Q:()};rank_todo=deque([Q]);rank_bad=None
        while rank_todo and rank_bad is None:
            T=rank_todo.popleft();w=rank_words[T]
            if len(w)==6:continue
            for i in selected:
                U=image(i,T)
                if U.bit_count()<=9:rank_bad=w+(i,);break
                if U not in rank_words:rank_words[U]=w+(i,);rank_todo.append(U)
        if rank_bad is not None:
            solver.add(z3.Or([z3.Not(choose[i]) for i in set(rank_bad)]))
            cuts.append(dict(kind='short_rank_word',word=list(rank_bad)));continue
        # Exact shortest unsafe word; all learned forbidden alphabets are literal.
        words={S:()};todo=deque([S]);bad=None
        while todo and bad is None:
            T=todo.popleft();w=words[T]
            if len(w)==11:continue
            for i in selected:
                U=image(i,T)
                if U.bit_count()<9 or U&A!=A:bad=w+(i,);break
                if U not in words:words[U]=w+(i,);todo.append(U)
        if bad is not None:
            letters=sorted(set(bad));solver.add(z3.Or([z3.Not(choose[i]) for i in letters]))
            cuts.append(dict(kind='unsafe_word',word=list(bad)));continue
        # A proper closed state set blocks SC for every subalphabet.
        obstruction=None
        for p in range(13):
            reached=set(graph(p,[(i,lambda q,i=i:rows[i][q]) for i in selected]))
            if len(reached)<13:obstruction=reached;break
        if obstruction is not None:
            escape=[i for i,row in enumerate(rows) if any(row[q] not in obstruction for q in obstruction)]
            solver.add(z3.Or([choose[i] for i in escape]));cuts.append(dict(kind='closed_states',states=sorted(obstruction),escape_letters=escape));continue
        # Pair closure certifies a nonmergeable pair without assuming sync.
        nonsync=None
        for p in range(13):
            for q in range(p):
                pair=tuple(sorted((p,q)));reached=graph(pair,[(i,lambda x,i=i:tuple(sorted((rows[i][x[0]],rows[i][x[1]])))) for i in selected])
                if not any(x==y for x,y in reached):nonsync=set(reached);break
            if nonsync is not None:break
        if nonsync is not None:
            escape=[i for i,row in enumerate(rows) if any(tuple(sorted((row[p],row[q]))) not in nonsync for p,q in nonsync)]
            solver.add(z3.Or([choose[i] for i in escape]));cuts.append(dict(kind='closed_pairs',pairs=[list(p) for p in sorted(nonsync)],escape_letters=escape));continue
        full=graph(Q,[(i,lambda T,i=i:image(i,T)) for i in selected])
        if S not in full:
            escape=[i for i in range(N) if any(image(i,T) not in full for T in full)]
            solver.add(z3.Or([choose[i] for i in escape]));cuts.append(dict(kind='unreachable_image',closure=sorted(full),escape_letters=escape));continue
        exact=graph(S,[(i,lambda T,i=i:image(i,T)) for i in selected])
        bads=[w for T,w in exact.items() if T.bit_count()<9 or T&A!=A];assert bads
        attaining=min(bads,key=len)
        reset=min((w for T,w in full.items() if T.bit_count()==1),key=len)
        assert len(attaining)==12
        actual=dict(selected_indices=selected,rows=[rows[i] for i in selected],S=[q for q in range(13) if S>>q&1],A=[3],
            value=len(attaining),reaching_word=list(full[S]),attaining_word=list(attaining),reset_word=list(reset),word_indices='original saved-pool indices')
        last='verified_literal_witness_pending_independent_audit';break
    out=dict(status=('time_budget_exhausted_without_witness' if last=='sat' and actual is None else last),last_solver_status=last,seed_cuts=len(seed['cuts']),parameter=[13,9,1],prefix=967,conditional_literal_pool=N,iterations=iterations,
        elapsed_seconds=time.monotonic()-(deadline-60),solver_version=z3.get_version_string(),cuts=cuts,actual=actual,
        complete_geometry_exclusion=False,no_authoritative_exclusion=True,no_new_numerical_extremum=actual is None,
        scope='Bounded saved-pool selector synthesis only. Solver UNSAT does not establish a global upper; positives still require independent original-automaton audit.',
        source_sha256={Path(__file__).name:sha256(Path(__file__).read_bytes()).hexdigest(),source:sha256((HERE/source).read_bytes()).hexdigest(),seedfile:sha256((HERE/seedfile).read_bytes()).hexdigest(),auditfile:sha256((HERE/auditfile).read_bytes()).hexdigest(),**{n:sha256((HERE/n).read_bytes()).hexdigest() for n in ['RANK_WORD_COMPRESSION_PRUNING_20261012.md','rank_word_compression_audit_20261012.json','FOLD_COMPRESSIBILITY_PREMISE_20261012.md','fold_compressibility_audit_20261012.json']}})
    dest.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k not in ('cuts','source_sha256','actual')}),flush=True)
if __name__=='__main__':main()
