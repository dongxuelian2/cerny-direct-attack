"""Conservative entire-active-pool transport to one fixed finite cover proof."""
from functools import lru_cache
from hashlib import sha256
import json
from pathlib import Path
HERE=Path(__file__).resolve().parent
POOL='b2_mixed_candidate967_literal_pool_20261012.json'
COVER='candidate967_cover_tree_audit_20261012.json'

@lru_cache(maxsize=1)
def saved():
    pool=json.loads((HERE/POOL).read_text())['candidate'];proof=json.loads((HERE/COVER).read_text())
    assert proof['status']=='pass' and proof['prefix']==967 and proof['complete_saved_pool_cover_exclusion']
    rows=pool['rows'];index={tuple(r):i for i,r in enumerate(rows)};assert len(index)==len(rows)
    groups=[sum(1<<i for i in R) for R in pool['required_groups']]
    return pool,index,groups,sha256((HERE/POOL).read_bytes()).hexdigest(),sha256((HERE/COVER).read_bytes()).hexdigest()

def certificate(rows,active,required,S):
    pool,index,groups,hp,hc=saved()
    if S!=pool['basis'][0] or not active or active.bit_count()>len(pool['rows']):return None
    assert 0<=active and active.bit_length()<=len(rows) and all(R>=0 for R in required)
    transport=[];bits=active
    while bits:
        bit=bits&-bits;bits-=bit;i=bit.bit_length()-1;j=index.get(tuple(rows[i]))
        if j is None:return None
        transport.append([i,j])
    if len({j for i,j in transport})!=len(transport):return None
    domains=[]
    for R in required:
        mapped=sum(1<<j for i,j in transport if R>>i&1)
        if not mapped:return None
        domains.append(mapped)
    implications=[]
    for k,R in enumerate(groups):
        eligible=[j for j,D in enumerate(domains) if D&~R==0]
        if not eligible:return None
        implications.append([k,eligible[0]])
    return dict(kind='saved_literal_rank_cover',initial_image=S,saved_pool=POOL,saved_pool_sha256=hp,
        saved_cover=COVER,saved_cover_sha256=hc,transport=transport,compulsory_group_implications=implications)
