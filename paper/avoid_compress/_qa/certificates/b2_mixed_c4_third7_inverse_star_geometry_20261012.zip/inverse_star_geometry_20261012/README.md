# Complete conditional native inverse-domain certificate

Python >=3.10, standard library. Parameter(13,9,1),target12.
B={0,4},C={1,4},D={2,4},H={0,1,2},protected state3.
The existing necessary entrance-fibre, mandatory-state and P1<=4 premises
are documented in investigation/B1_B2_INVERSE_UNION_EXCLUSION.md.
All18277 possible immediate graphs are covered, for arbitrary finite alphabets.
The independent checker uses literal independent sets, clique-union kernels
and full output quotas; no colouring-generator import is used by it.
It checks a retained positive control, rejects9 corruptions and checks7 union controls.
This excludes only the named native geometry, not all equality configurations.
No numerical F value, alphabet separation or folded-profile transport is asserted.
The historical baseline is opaque bound input, not current authoritative state.
Move aside the following two reports from _qa, then run there in order:
b2_mixed_c4_third7_inverse_native_inventory_20261012.json
b2_mixed_c4_third7_inverse_native_audit_20261012.json

python -B enumerate_inverse_star_geometry_20261012.py
python -B check_inverse_star_geometry_20261012.py
Both recreated reports must match their stored SHA256.
Separate gated adoption is required before changing the authoritative frontier.
