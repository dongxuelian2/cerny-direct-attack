"""Verify the QA handoff and compute provisional composition, without writes
to any accepted source, manuscript, release or current checkpoint.
"""
from pathlib import Path
import json,hashlib
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent/'investigation';PAPER=ROOT.parent
def read(n):return json.loads((ROOT/n).read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    active=read('active_research.json');cp=read(active['current_auxiliary_audit'])
    for n,h in cp['source_sha256'].items():assert sha(ROOT/n)==h,n
    audit=json.loads((HERE/'b1_b2_inverse_all_negative_independent_audit.json').read_text());assert audit['status']=='pass' and not audit['accepted_frontier_changed']
    for n,h in audit['qa_source_sha256'].items():assert sha(HERE/n)==h,n
    for n,h in audit['frozen_source_sha256'].items():assert sha(ROOT/n)==h,n
    batch=json.loads((HERE/'b1_b2_inverse_probe_all_batch.json').read_text());assert len(batch['runs'])==136 and len({z['id'] for z in batch['runs']})==136
    negatives={z['id'] for z in batch['runs'] if z['status']=='completed_exploration' and z['exploratory_negative']}
    assert negatives==set(audit['independently_verified_negative_geometries'])
    inv=read('small_first_third_inventory.json')['records'];j=active['joint_fiber_cases']
    before=[z for z in inv if z['joint_id'] not in j['unrestricted_excluded_orbits'] and z['id'] not in j['unrestricted_additional_small_first_third_exclusions']]
    assert len(before)==136 and {z['id'] for z in before}=={z['id'] for z in batch['runs']}
    after=[z for z in before if z['id'] not in negatives]
    new_u_joints=sorted({z['joint_id'] for z in before}-{z['joint_id'] for z in after})
    cuts={}
    for array in [read('common_block_profiles_audit.json')['profile_cuts'],active['two_cover_unique_kernel_profile_cuts'],active['two_cover_exact_kernel_profile_cuts'],active['three_cover_atom_kernel_profile_cuts']]:
        for z in array:cuts.setdefault(z['id'],set()).update(map(tuple,z['removed_parent_pairs']))
    binary_before=[z for z in inv if z['joint_id'] not in j['binary_excluded_orbits'] and z['id'] not in j['binary_additional_small_first_third_exclusions']]
    profiles=lambda z:set(map(tuple,z['binary_profile_pairs']))-cuts.get(z['id'],set())
    assert (len(binary_before),sum(bool(profiles(z)) for z in binary_before),sum(len(profiles(z)) for z in binary_before))==(120,105,448)
    binary_after=[z for z in binary_before if z['id'] not in negatives]
    new_b_joints=sorted({z['joint_id'] for z in binary_before if profiles(z)}-{z['joint_id'] for z in binary_after if profiles(z)})
    checks=0
    for mf,folder in [(PAPER/'SHA256SUMS.txt',PAPER),(PAPER/'release/ARCHIVE_SHA256SUMS.txt',PAPER/'release')]:
        for line in mf.read_text().splitlines():
            h,n=line.split('  ',1);assert sha(folder/n)==h,n;checks+=1
    assert checks==121
    for n,h in cp['accepted_artifact_sha256'].items():assert sha(PAPER/n)==h,n
    result=dict(status='pass',base_checkpoint=active['current_auxiliary_audit'],tested_geometries=136,completed_explorations=sum(r['status']=='completed_exploration' for r in batch['runs']),budget_exhausted=sum(r['status']=='budget_exhausted' for r in batch['runs']),independently_verified_negative_geometries=sorted(negatives),proposed_remaining_unrestricted_geometries=len(after),proposed_new_unrestricted_joint_exclusions=new_u_joints,proposed_remaining_binary_geometries=len(binary_after),proposed_remaining_binary_typed=sum(bool(profiles(z)) for z in binary_after),proposed_remaining_binary_profiles=sum(len(profiles(z)) for z in binary_after),proposed_new_binary_joint_exclusions=new_b_joints,accepted_frontier_changed=False,ready_for_immutable_certificate_preparation=True,accepted_publication_checksums=checks,accepted_artifacts_unchanged=6,interval=[11,12],goal_achieved=False,scope='QA handoff only. Proposed conditional geometry composition is not yet incorporated into a new accepted checkpoint; no numerical F conclusion or alphabet separation.',source_sha256={n:sha(HERE/n) for n in ['b1_b2_inverse_all_negative_independent_audit.json','b1_b2_inverse_probe_all_batch.json',Path(__file__).name,'B1_B2_INVERSE_DOMAIN_METHOD.md']})
    (HERE/'b1_b2_inverse_probe_handoff.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result),flush=True)
if __name__=='__main__':main()
