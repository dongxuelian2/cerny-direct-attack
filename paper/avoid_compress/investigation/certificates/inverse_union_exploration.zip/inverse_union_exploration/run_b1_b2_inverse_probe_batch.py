"""Bounded exploratory batch; timeouts never exclude a geometry."""
from pathlib import Path
import json, subprocess, sys
HERE=Path(__file__).resolve().parent

def main():
    preflight=json.loads((HERE/'b1_b2_inverse_preflight.json').read_text())
    order=sorted(preflight['records'],key=lambda z:z['field_kernel_entries'])
    complete='--all' in sys.argv
    runs=[]
    for z in (order if complete else order[:12]):
        name=z['id']
        try:
            p=subprocess.run([sys.executable,'-B',str(HERE/'probe_b1_b2_inverse_domain.py'),name],cwd=HERE,capture_output=True,text=True,timeout=8 if complete else 30)
        except subprocess.TimeoutExpired:
            runs.append(dict(id=name,status='budget_exhausted',negative=False));print(name+': budget exhausted; unresolved',flush=True);continue
        if p.returncode:
            raise RuntimeError(name+'\n'+p.stdout+'\n'+p.stderr)
        result=json.loads(p.stdout.splitlines()[-1])
        runs.append(dict(id=name,status='completed_exploration',global_classes=result['global_classes'],counts=result['counts'],exploratory_negative=result['counts'].get('retained_overapproximation',0)==0,seconds=result['seconds']))
        print(json.dumps(runs[-1]),flush=True)
    result=dict(status='exploration_only',runs=runs,new_certified_exclusions=[],scope='No changes to the accepted frontier. Timeouts and imported-generator results are not certificates.')
    (HERE/('b1_b2_inverse_probe_all_batch.json' if complete else 'b1_b2_inverse_probe_batch.json')).write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(dict(status=result['status'],completed=sum(r['status']=='completed_exploration' for r in runs),budgets_exhausted=sum(r['status']=='budget_exhausted' for r in runs))),flush=True)

if __name__=='__main__':main()
