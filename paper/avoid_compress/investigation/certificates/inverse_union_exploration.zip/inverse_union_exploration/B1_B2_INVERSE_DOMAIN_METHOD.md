# Generalizing the fixed-parameter inverse-domain test

This is an auxiliary, conditional argument at `(n,s,r,ac)=(13,9,1,12)`.
It gives neither a numerical extremum nor an alphabet separation. The
accepted paper remains a partial answer. The current accepted checkpoint
is `investigation/AUXILIARY_AUDIT_20261011_01.json`; this exploratory QA
directory has not been incorporated into a new immutable certificate.

Use the already audited entrance-fibre inventory, the cover
`H={0,1,2}` of `P5`, and the bound `|P1|<=4`. For a retained B1/B2 third
geometry, every actual image through depth eight is a nine-set containing
`A={3}` and meeting `B,C,D` once. Its frame intersection `J` is therefore
mandatory through depth four. The mandatory-core isolation argument makes
`J` isolated in `P7`. The preflight explicitly checks that `J` is disjoint
from `H` for each of the 136 current geometries. No disjointness premise is
silently transferred from the older B3 computation.

For every actual letter, its three preimage fields and exact kernel occur
in the independently audited native field/kernel inventory. The actual
immediate-pair graph `P1` is the union of these kernels over the actual
alphabet. Thus enumerate the whole union closure of the native kernel
masks, retaining unions of at most four pair edges. This is complete for
arbitrary finite alphabets: every partial union of a true union also has
at most four edges, so iterative union closure cannot omit it. A zero
union is impossible for a synchronizing automaton with more than one
state, since it would make every letter a permutation.

The independent checker obtains the same graph catalogue differently:
it tests every nonempty edge subset of size at most four in the union of
the native kernels. Such a subset `G1` is a union of native kernels iff
the union of all native kernels contained in `G1` equals `G1`. This test
does not require guessing an alphabet or bounding its size.

Fix one proposed graph `G1`. Every actual letter kernel is a clique-union
subgraph of `G1`. Set `G=G1 union K_C union K_D`, which is contained in
`P3`. Each letter is injective on the ten inputs outside `H`; their images
form a ten-set independent in `G`, since an edge between them would lift
to a `P4` edge outside the cover `H`. Every image of a `J` input must be
isolated in `G` on the full available output set `Qf`: an available
neighbor would lift to a `P4` pair incident to `J`. This includes outputs
of kernel blocks lying wholly in `H`.

An exact kernel block lies in a unique input atom of the three preimage
fields. Classify blocks as outside non-J, J-singleton, or H-only. Assign
distinct output states of the corresponding output atom to the blocks.
Equivalently color outputs 0 (omitted), 1 (outside non-J block), 2
(J-singleton), or 3 (H-only block), imposing independence of colors 1/2,
isolation of color 2 among all positive colors, and equality of input
block and output color counts in every atom. Independent atom/type
bijections prove this is an exact description of the constrained
one-letter domain. It imposes no all-word safety sufficiency claim.

The generator colors active graph vertices and uses residual atom quotas
on isolated vertices. The independent checker chooses literal ten-state
independent sets, all subsets of their three-point complement for H-only
outputs, and all eligible `|J|`-subsets for protected outputs. It then
matches full atom/type quotas. For every input block, the union of targets
in its atom/type over these literal assignments gives exactly its
possible arrows. The checker separately rebuilds clique-union kernels
from all edge subsets of each proposed `G1`.

Every actual alphabet must supply the three entrance preimages
`pre(A)=B`, `pre(B)=C`, and `pre(C)=D`; suppliers may coincide. A missing
supplier rejects a graph class. Otherwise form the union of all allowed
arrows over all allowed letters. A nonempty proper set closed under these
arrows prevents strong connectivity for every actual alphabet. A strongly
connected maximal graph is retained as an overapproximation; it is not
a realization, nor a proof of synchronization, safety, or S reachability.

Canonical D rejection covers all labelled copies because a permutation
within the H,B,C membership cells transports D, all fields and kernels,
the mandatory frame intersection, the graph catalogue, and every proper
closed set. The checker enumerates these D copies and verifies the
transport. Exclusion applies to all such nine-sets, so in particular to
the actual reachable images required by the article. Omitting the
reachability restriction here only enlarges the tested domain.

The complete 136-record exploratory batch has 108 completed computations
and 28 budget exhaustions. All 24 negative geometries among the completed
computations have passed the independent checker, together with a retained
control. A timeout supplies no negative result. The separately checked
provisional composition leaves 112 unrestricted geometries and
99 binary geometries (95 typed families, 437 profiles); it excludes no
additional whole joint. These numbers have not yet been incorporated
into an immutable certificate or the accepted checkpoint. No whole joint
is excluded merely because some of its D geometries are excluded.
