"""Read-only preparation for a possible general inverse-clique search.

No geometry is excluded here; all counts refer to the current admitted
B1/B2 third records and not to possible automata.
"""
from pathlib import Path
from itertools import combinations
from collections import Counter
import hashlib, json

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent / 'investigation'

def read(name):
    return json.loads((ROOT / name).read_text())

def main():
    active = read('active_research.json')
    cuts = active['joint_fiber_cases']
    kernel_records = {z['id']: z for z in read('three_cover_atom_kernel_inventory.json')['records']}
    Q, H = set(range(13)), {0, 1, 2}
    frames = [{3} | set(S) for S in combinations(sorted(Q - {3}), 8)]
    records = []
    counts = Counter()
    for z in read('small_first_third_inventory.json')['records']:
        if z['joint_id'] in cuts['unrestricted_excluded_orbits'] or z['id'] in cuts['unrestricted_additional_small_first_third_exclusions']:
            continue
        native = kernel_records[z['id']]
        B, C, D = [set(z[k]) for k in ('B', 'C', 'D')]
        feasible = [S for S in frames if all(len(S & X) == 1 for X in (B, C, D))]
        assert len(feasible) == z['feasible_nine_sets']
        J = set.intersection(*feasible)
        assert sorted(J) == native['mandatory'] and native['unrestricted_admitted']
        K = H - J
        assert len(K) >= 2  # Already accepted mandatory-core / cover-floor cuts.
        all_edges = [e for e in combinations(range(13), 2) if set(e) & K and not set(e) & J]
        for f in native['fields']:
            for mask in f['compatible_kernel_masks']:
                edges = [e for i, e in enumerate(combinations(range(13), 2)) if mask >> i & 1]
                assert len(edges) <= 4 and all(set(e) & K and not set(e) & J for e in edges)
        # Every J input is outside K, even when J meets the original H.
        assert not J & K
        counts[(len(B), len(K), len(J))] += 1
        records.append(dict(id=z['id'],joint_id=z['joint_id'],B=sorted(B),C=sorted(C),D=sorted(D),mandatory=sorted(J),reduced_guard=sorted(K),outside_inputs=13-len(K),available_immediate_edges=len(all_edges),frames=len(feasible),fields=len(native['fields']),field_kernel_entries=sum(len(f['compatible_kernel_masks']) for f in native['fields']),supplier_kernel_counts=native['supplier_kernel_counts']))
    assert len(records) == 136
    result = dict(status='preflight_only',parameter=[13,9,1],records=records,counts=[dict(B_size=b,guard_size=k,mandatory_size=j,geometries=v) for (b,k,j),v in sorted(counts.items())],geometries=136,new_exclusions=[],scope='No F value, alphabet separation or new negative certificate. Reduced guards and domain-size bookkeeping only.',source_sha256={n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in ['active_research.json','small_first_third_inventory.json','three_cover_atom_kernel_inventory.json']})
    (HERE/'b1_b2_inverse_preflight.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('records','source_sha256')}))
    print(json.dumps(dict(smallest_domains=[dict(id=z['id'],frames=z['frames'],field_kernel_entries=z['field_kernel_entries'],guard=z['reduced_guard'],mandatory=z['mandatory']) for z in sorted(records,key=lambda z:z['field_kernel_entries'])[:12]])))

if __name__ == '__main__':
    main()
