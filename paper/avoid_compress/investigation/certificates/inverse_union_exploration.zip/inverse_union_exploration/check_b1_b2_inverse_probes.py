"""Independent verification of selected exploratory inverse domains.

No generator imports. Immediate graphs are rebuilt by edge-subset tests;
output domains use literal independent sets, and kernel catalogues use
clique-union graphs rather than the guard partition generator.
This QA report does not modify the accepted frontier.
"""
from pathlib import Path
from itertools import combinations, product
from collections import Counter
import json, hashlib, time, sys

HERE=Path(__file__).resolve().parent;ROOT=HERE.parent/'investigation'
Q=set(range(13));H={0,1,2};A={3};PAIRS=list(combinations(range(13),2));BITS={e:1<<i for i,e in enumerate(PAIRS)}
SELECTED=['b2_mixed_c12_third7','b2_in_c6_third1','b2_in_c5_third2','b2_mixed_c5_third3']

def read(n):return json.loads((ROOT/n).read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def edges(m):return [e for i,e in enumerate(PAIRS) if m>>i&1]

def graphs(kernels):
    universe=sorted({e for m in kernels for e in edges(m)})
    result=[]
    for size in range(1,5):
        for es in combinations(universe,size):
            mask=sum(BITS[e] for e in es)
            # Exactly the graphs realizable as unions of available kernels.
            cover=0
            for m in kernels:
                if not m&~mask:cover|=m
            if cover==mask:result.append(mask)
    return sorted(result)

def kernel_catalogue(P1):
    E=edges(P1);answer=[]
    for chosen in product((False,True),repeat=len(E)):
        subset={e for e,v in zip(E,chosen) if v};blocks=[{q} for q in range(13)]
        for u,v in subset:
            merged=[b for b in blocks if u in b or v in b]
            blocks=[b for b in blocks if b not in merged]+[set().union(*merged)]
        if subset=={e for b in blocks for e in combinations(sorted(b),2)}:
            answer.append((sum(BITS[e] for e in subset),blocks))
    return answer

def literal_quotas(G,out,Jsize):
    adj=[set() for _ in range(13)]
    for u,v in G:adj[u].add(v);adj[v].add(u)
    quotas={};count=0
    for labels in combinations(range(13),10):
        I=set(labels)
        if any(adj[q]&I for q in I):continue
        complement=sorted(Q-I)
        for size in range(4):
            for extra in combinations(complement,size):
                T=set(extra);available=I|T
                eligible=[q for q in sorted(I) if not adj[q]&available]
                for protected in combinations(eligible,Jsize):
                    L=set(protected);counts=[0]*24;targets=[0]*24
                    for states,col in [(I-L,1),(L,2),(T,3)]:
                        for q in states:
                            i=3*out[q]+col-1;counts[i]+=1;targets[i]|=1<<q
                    entry=quotas.setdefault(tuple(counts),[0]*24)
                    for i,v in enumerate(targets):entry[i]|=v
                    count+=1
    return quotas,count

def main():
    start=time.time();active=read('active_research.json');checkpoint=read(active['current_auxiliary_audit'])
    selected=SELECTED
    all_negative='--all-negative' in sys.argv
    if all_negative:
        batch=json.loads((HERE/'b1_b2_inverse_probe_all_batch.json').read_text())
        assert batch['status']=='exploration_only' and len(batch['runs'])==136
        selected=sorted(r['id'] for r in batch['runs'] if r['status']=='completed_exploration' and r['exploratory_negative'])+[SELECTED[-1]]
    assert checkpoint['status'].startswith('Audited')
    for n,h in checkpoint['source_sha256'].items():assert sha(ROOT/n)==h,n
    native={z['id']:z for z in read('three_cover_atom_kernel_inventory.json')['records']}
    geometries={z['id']:z for z in read('small_first_third_inventory.json')['records']}
    allframes=[{3}|set(S) for S in combinations(sorted(Q-A),8)]
    audit_records=[];bindings={};negative=[];totals=Counter()
    for name in selected:
        path=HERE/(name+'_inverse_probe.json');data=json.loads(path.read_text());z=geometries[name];ns=native[name]
        for n,h in data['source_sha256'].items():assert sha(ROOT/n)==h,n
        bindings[path.name]=sha(path)
        B,C,D=map(set,(z['B'],z['C'],z['D']));J=set(ns['mandatory'])
        assert not J&H and J==set.intersection(*(S for S in allframes if all(len(S&X)==1 for X in (B,C,D))))
        kernels=sorted({m for f in ns['fields'] for m in f['compatible_kernel_masks']})
        expected=graphs(kernels);assert data['unique_kernel_masks']==kernels and [c['P1_mask'] for c in data['records']]==expected and data['global_classes']==len(expected)
        # Verify all D-orbit transports under H,A,B,C-preserving permutations.
        cells=[{q for q in Q-A if tuple(q in X for X in (H,B,C))==sig} for sig in product((False,True),repeat=3)]
        transports=0;closed_transports=0
        for size in range(1,5):
            for item in combinations(sorted(Q-A),size):
                R=set(item)
                if len(R-H)>1 or [len(R&cell) for cell in cells]!=z['cell_signature']:continue
                perm={3:3}
                for cell in cells:perm.update(zip(sorted(cell&D)+sorted(cell-D),sorted(cell&R)+sorted(cell-R)))
                assert set(perm)==set(perm.values())==Q and {perm[q] for q in D}==R and all({perm[q] for q in X}==X for X in (H,A,B,C))
                feasible=[S for S in allframes if all(len(S&X)==1 for X in (B,C,R))]
                assert len(feasible)==z['feasible_nine_sets'] and set.intersection(*feasible)=={perm[q] for q in J}
                for c in data['records']:
                    if c['reason']!='maximal_graph_not_SC':continue
                    closed={perm[q] for q in c['closed_set']}
                    assert closed and closed!=Q
                    assert all({perm[q] for q in c['maximal_arrows'][p]}<=closed for p in c['closed_set'])
                    closed_transports+=1
                transports+=1
        assert transports==z['labelled_D']==z['orbit_size']
        out=[sum((q in X)<<(2-i) for i,X in enumerate((A,B,C))) for q in range(13)]
        cache={};counts=Counter();colourings=0;tested=0
        for c in data['records']:
            P1=c['P1_mask'];catalog=kernel_catalogue(P1)
            # Independently recover all atom-compatible native kernels in P1.
            atom_masks=[];typed=[]
            for f in ns['fields']:
                ins=[sum((q in X)<<(2-i) for i,X in enumerate(map(set,(f['preA'],f['preB'],f['preC'])))) for q in range(13)]
                local=[];variants=[]
                for m,blocks in catalog:
                    if any(len({ins[q] for q in b})>1 or (len(b)>1 and b&J) for b in blocks):continue
                    if any(len(b-H)>1 for b in blocks):continue
                    capacity=[sum(ins[min(b)]==a for b in blocks) for a in range(8)]
                    if any(capacity[a]>out.count(a) for a in range(8)):continue
                    local.append(m);variants.append((m,blocks,ins))
                assert sorted(local)==[m for m in f['compatible_kernel_masks'] if not m&~P1]
                atom_masks.append(local);typed.append(variants)
            prelim=[any(set(f[key])==X and atom_masks[i] for i,f in enumerate(ns['fields'])) for key,X in [('preA',B),('preB',C),('preC',D)]]
            if not all(prelim):
                assert c['reason']=='preliminary_missing_supplier' and c['supplier_options']==prelim
                counts[c['reason']]+=1;continue
            G=set(edges(P1))|set(combinations(sorted(C),2))|set(combinations(sorted(D),2));assert c['G']==[list(e) for e in sorted(G)]
            key=tuple(sorted(G))
            if key not in cache:
                cache[key],n=literal_quotas(G,out,len(J));colourings+=n
            quota=cache[key];allowed=[];arrows=[0]*13
            for variants in typed:
                local=[]
                for m,blocks,ins in variants:
                    signature=[0]*24;tagged=[]
                    for b in blocks:
                        col=2 if b&J else 1 if b-H else 3;i=3*ins[min(b)]+col-1
                        signature[i]+=1;tagged.append((b,i))
                    target=quota.get(tuple(signature));tested+=1
                    if target is None:continue
                    local.append(m)
                    for b,i in tagged:
                        for p in b:arrows[p]|=target[i]
                allowed.append(sorted(local))
            assert c['field_kernel_masks']==allowed
            assert c['maximal_arrows']==[[q for q in range(13) if a>>q&1] for a in arrows]
            suppliers=[any(set(f[key])==X and allowed[i] for i,f in enumerate(ns['fields'])) for key,X in [('preA',B),('preB',C),('preC',D)]]
            assert suppliers==c['suppliers']
            if not all(suppliers):assert c['reason']=='missing_supplier' and c['closed_set'] is None
            elif c['reason']=='maximal_graph_not_SC':
                R=set(c['closed_set']);mask=sum(1<<q for q in R)
                assert R and R!=Q and all(not arrows[p]&~mask for p in R)
            else:
                assert c['reason']=='retained_overapproximation' and c['closed_set'] is None
                for root in Q:
                    R={root}
                    while True:
                        expanded=R|{q for p in R for q in Q if arrows[p]>>q&1}
                        if expanded==R:break
                        R=expanded
                    assert R==Q
            counts[c['reason']]+=1
        assert dict(counts)==data['counts']
        if not counts['retained_overapproximation']:negative.append(name)
        totals.update(counts)
        audit_records.append(dict(id=name,global_classes=len(expected),counts=dict(counts),literal_output_colourings=colourings,quota_tests=tested,labelled_D_transports=transports,closed_set_transports=closed_transports))
        print(json.dumps(audit_records[-1]),flush=True)
    assert negative==selected[:-1] and totals['retained_overapproximation']>0
    if all_negative:bindings['b1_b2_inverse_probe_all_batch.json']=sha(HERE/'b1_b2_inverse_probe_all_batch.json')
    result=dict(status='pass',parameter=[13,9,1],records=audit_records,independently_verified_negative_geometries=negative,positive_control=selected[-1],accepted_frontier_changed=False,seconds=round(time.time()-start,2),scope='Conditional one-letter inverse-domain checks. No numerical F value, alphabet separation or whole-joint exclusion.',qa_source_sha256={**bindings,Path(__file__).name:sha(Path(__file__))},frozen_source_sha256={n:sha(ROOT/n) for n in ['active_research.json',active['current_auxiliary_audit'],'small_first_third_inventory.json','three_cover_atom_kernel_inventory.json']})
    (HERE/('b1_b2_inverse_all_negative_independent_audit.json' if all_negative else 'b1_b2_inverse_probe_independent_audit.json')).write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('records','qa_source_sha256','frozen_source_sha256')}),flush=True)

if __name__=='__main__':main()
